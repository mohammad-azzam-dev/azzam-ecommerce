<?php

use App\Model\BusinessSetting;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class PaymentMethodsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        BusinessSetting::updateOrCreate(
            [
                'key' => 'myFatoorah',
            ],
            [
                'value' => json_encode([
                    'status' => 0,
                    'api_key' => '',
                    'is_test' => 1,
                ]),
            ]
        );
    }
}
