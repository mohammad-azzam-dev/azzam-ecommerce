<?php

return [
    'api_key' => env('MYFATOORAH_API_KEY', ''),
    'is_test' => env('MYFATOORAH_IS_TEST', false),
];
